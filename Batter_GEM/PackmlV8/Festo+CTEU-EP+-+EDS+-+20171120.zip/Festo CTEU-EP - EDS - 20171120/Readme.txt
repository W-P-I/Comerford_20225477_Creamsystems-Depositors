CTEU-EP EDS

There are two EDS files contained in this archive.
Usually you should use CTEU-EP.eds. 
If you are an OMRON user please use CTEU-EP_NoConfig.eds.

Festo AG & Co KG 2017